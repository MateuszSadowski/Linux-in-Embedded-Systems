Proszę uruchomić skrypt z wnętrza tego katalogu. (Przed uruchomieniem wykonać "cd [LINSW LAB 1] Mateusz Sadowski"
